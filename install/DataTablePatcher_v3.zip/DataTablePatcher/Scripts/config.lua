local json = require("Libs.dkjson")



local SETTINGS_FILENAME = "config.json"



local defaults = {

	hotreload = false,

	debug = false,

	--- Relative to mod root (folder containing Scripts/).

	dataTablesRelativePath = "../../../../../Content/DataTables",

}



local function getModRootDirectory()

	local scriptPath = debug.getinfo(1, "S").source

	local scriptDir = scriptPath:match("@?(.*[\\/])"):gsub("[\\/]$", ""):match("(.*[\\/])")

	return (scriptDir or ""):gsub("[\\/]+$", "")

end



local M = {

	defaults = defaults,

	settingsFilename = SETTINGS_FILENAME,

	hotreload = defaults.hotreload,

	debug = defaults.debug,

	dataTablesRelativePath = defaults.dataTablesRelativePath,

}



function M.getPath()

	local root = getModRootDirectory()

	local sep = root:find("\\") and "\\" or "/"

	return root .. sep .. SETTINGS_FILENAME

end



function M.Log(...)

	if M.debug then

		print(...)

	end

end



local function applyDefaultsToModule()

	M.hotreload = defaults.hotreload

	M.debug = defaults.debug

	M.dataTablesRelativePath = defaults.dataTablesRelativePath

end



local function defaultSettingsJson()

	return table.concat({

		"{\n",

		'  "hotreload": false,\n',

		'  "debug": false,\n',

		'  "dataTablesRelativePath": "../../../../../Content/DataTables"\n',

		"}\n",

	})

end



--- Reload from config.json (mod root). Creates default file if missing.

function M.load()

	local path = M.getPath()

	local f = io.open(path, "r")

	if not f then

		local wf = io.open(path, "w")

		if wf then

			wf:write(defaultSettingsJson())

			wf:close()

			M.Log("[BetterGameplay] Created default settings: " .. path .. "\n")

		end

		applyDefaultsToModule()

		M.hotreload = true

		return M

	end

	local content = f:read("*all")

	f:close()

	local data = json.decode(content)

	if type(data) ~= "table" then

		M.Log("[BetterGameplay] Warning: invalid JSON in " .. path .. ", using defaults\n")

		applyDefaultsToModule()

		return M

	end

	M.hotreload = data.hotreload

	if M.hotreload == nil then M.hotreload = defaults.hotreload end

	M.debug = data.debug

	if M.debug == nil then M.debug = defaults.debug end

	M.dataTablesRelativePath = data.dataTablesRelativePath

	if M.dataTablesRelativePath == nil or M.dataTablesRelativePath == "" then

		M.dataTablesRelativePath = defaults.dataTablesRelativePath

	end

	return M

end



M.load()



return M

