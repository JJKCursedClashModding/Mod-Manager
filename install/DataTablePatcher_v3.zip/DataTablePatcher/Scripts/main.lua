local utils = require("utils")
local fields = require("fields")
local config = require("config")

utils.EnsureDataDirectoryExists()

local function InitializeDataTables()
	config.Log("[BetterGameplay] Scanning Content/DataTables (subfolders) and applying patches \n")
	return utils.ApplyAllDiscoveredPatches(fields.GetPatchOptions)
end

LoopAsync(1000, function()
	return InitializeDataTables()
end)

if config.hotreload then
	LoopAsync(1000, function()
		utils.ApplyChangedDiscoveredPatches(fields.GetPatchOptions)
	end)
end
