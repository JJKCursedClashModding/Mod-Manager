local json = require("Libs.dkjson")
local config = require("config")

local function GetScriptDirectory()
    local scriptPath = debug.getinfo(1, "S").source
    local scriptDir = scriptPath:match("@?(.*[\\/])"):gsub("[\\/]$", ""):match("(.*[\\/])")
    return scriptDir or ""
end

--- Mod root (parent of Scripts/). Content JSON lives under game Content/DataTables.
local function GetModRootDirectory()
    return GetScriptDirectory()
end

local function GetDataDirectoryPath()
    local root = GetModRootDirectory():gsub("[\\/]+$", "")
    local sep = root:find("\\") and "\\" or "/"
    local rel = tostring(config.dataTablesRelativePath or ""):gsub("[\\/]+$", "")
    if rel == "" then
        rel = tostring(config.defaults.dataTablesRelativePath):gsub("[\\/]+$", "")
    end
    rel = rel:gsub("/", sep):gsub("\\", sep)
    return root .. sep .. rel .. sep
end

local function normalizeDirForListing(dir)
    local sep = dir:find("\\") and "\\" or "/"
    if dir:sub(-1) ~= sep and dir:sub(-1) ~= "/" and dir:sub(-1) ~= "\\" then
        dir = dir .. sep
    end
    return dir, sep
end

local okLfs, lfs = pcall(require, "lfs")

-- Cached once at first use: the normalised absolute path to the data directory.
-- Avoids repeated debug.getinfo + regex on every hot-reload poll tick.
local _dataDirNorm = nil
local function getDataDirNorm()
    if not _dataDirNorm then
        _dataDirNorm = normalizeDirForListing(GetDataDirectoryPath())
    end
    return _dataDirNorm
end

-- Cached list of rel paths under the data dir; invalidated by SyncDataJsonFilesBaseline
-- after each successful apply so that new/removed files are picked up next cycle.
local _cachedRelPaths = nil

--- Ensures Content/DataTables exists (recursive when LuaFileSystem is available).
local function EnsureDataDirectoryExists()
    local path = GetDataDirectoryPath()
    path = path:gsub("[\\/]+$", "")
    if okLfs and lfs and lfs.mkdir and lfs.attributes then
        if lfs.attributes(path) then return true end
        local sep = path:find("\\") and "\\" or "/"
        local accumulated = ""
        for part in path:gmatch("[^/\\]+") do
            if accumulated == "" and part:match("^%a:$") then
                accumulated = part
            else
                accumulated = accumulated .. (accumulated ~= "" and sep or "") .. part
            end
            local a = lfs.attributes(accumulated)
            if not a then
                local ok, err = lfs.mkdir(accumulated)
                if not ok then
                    config.Log("[BetterGameplay] Error: could not create directory " .. tostring(accumulated) .. ": " .. tostring(err) .. "\n")
                    return false
                end
            end
        end
        return true
    end
    -- Do not infer OS from path slashes: UE4SS may report script paths with "/" only; "mkdir -p" then breaks cmd.exe.
    local sepWin = (package.config:sub(1, 1) == "\\")
    local winPath = path:gsub("/", "\\")
    local cmd = sepWin and ('cmd /c if not exist "' .. winPath .. '" mkdir "' .. winPath .. '"')
        or ('mkdir -p "' .. path .. '"')
    local ok = os.execute(cmd)
    return ok == 0 or ok == true
end

local function joinDataRootRel(rootNorm, rel)
    local sep = rootNorm:find("\\") and "\\" or "/"
    local r = rel:gsub("/", sep):gsub("\\", sep)
    return rootNorm .. r
end

--- Paths like subdir/File.json under Content/DataTables (JSON only in immediate subfolders).
local function enumeratePatchJsonRelPathsCmd(rootNorm)
    local out = {}
    -- Single spawn using cmd for-loops to emit "subdir\file.json" pairs directly.
    -- This avoids the path-resolution mismatch that occurs when the rootNorm
    -- contains ".." components: dir /b /s returns fully-resolved paths, but our
    -- rootNorm string is unresolved, so prefix-stripping would fail.
    -- %~nxd = name of the subdirectory, %~nxf = name of the JSON file.
    local q = (rootNorm:gsub("[\\/]+$", "")):gsub("/", "\\")
    local h = io.popen('cmd /c for /d %d in ("' .. q .. '\\*") do @for %f in ("%d\\*.json") do @echo %~nxd\\%~nxf 2>nul')
    if not h then return out end
    for line in h:lines() do
        line = line:match("^%s*(.-)%s*$")
        if line and line ~= "" then
            local sep1 = line:find("[/\\]")
            if sep1 then
                local fname = line:sub(sep1 + 1)
                if fname:sub(1, 1) ~= "_" then
                    out[#out + 1] = line:gsub("\\", "/")
                end
            end
        end
    end
    h:close()
    table.sort(out)
    return out
end

local function enumeratePatchJsonRelPaths()
    if _cachedRelPaths then return _cachedRelPaths end
    local rootNorm = getDataDirNorm()
    local out = {}
    if okLfs and lfs and lfs.dir and lfs.attributes then
        for sub in lfs.dir(rootNorm) do
            if sub ~= "." and sub ~= ".." then
                local fullSub = rootNorm .. sub
                local a = lfs.attributes(fullSub)
                if a and a.mode == "directory" then
                    local subDir = normalizeDirForListing(fullSub)
                    for f in lfs.dir(subDir) do
                        if f ~= "." and f ~= ".." and f:sub(1, 1) ~= "_" and f:lower():match("%.json$") then
                            out[#out + 1] = sub:gsub("\\", "/") .. "/" .. f:gsub("\\", "/")
                        end
                    end
                end
            end
        end
        table.sort(out)
    else
        out = enumeratePatchJsonRelPathsCmd(rootNorm)
    end
    _cachedRelPaths = out
    return _cachedRelPaths
end

--- Fingerprint for change detection: mod time + size if lfs, else size + djb2 hash (full read).
local function fingerprintDataFile(absPath)
    if okLfs and lfs and lfs.attributes then
        local a = lfs.attributes(absPath)
        if not a then return nil end
        return string.format("%d|%d", a.size or 0, a.modification or 0)
    end
    local f = io.open(absPath, "rb")
    if not f then return nil end
    local data = f:read("*a")
    f:close()
    if not data then return "0|0" end
    local h = 5381
    for i = 1, #data do
        h = ((h * 33 + string.byte(data, i)) % 4294967296)
    end
    return string.format("%d|%u", #data, h)
end

--- Map: rel path (subdir/file.json) -> fingerprint for hot reload.
local function captureDataJsonSnapshot()
    local rootNorm = getDataDirNorm()
    local snap = {}
    for _, rel in ipairs(enumeratePatchJsonRelPaths()) do
        snap[rel] = fingerprintDataFile(joinDataRootRel(rootNorm, rel))
    end
    return snap
end

local function dataSnapshotsEqual(a, b)
    if not a or not b then return a == b end
    for k, v in pairs(a) do
        if b[k] ~= v then return false end
    end
    for k, v in pairs(b) do
        if a[k] ~= v then return false end
    end
    return true
end

--- Baseline for HaveDataJsonFilesChanged().
local _dataJsonBaselineSnapshot = nil

--- Call after a successful ApplyJSON / reload so "updated" is false until files change again.
local function SyncDataJsonFilesBaseline()
    _cachedRelPaths = nil   -- re-enumerate on next snapshot so new/removed files are picked up
    _dataJsonBaselineSnapshot = captureDataJsonSnapshot()
end

--- True if any patch JSON under Content/DataTables/*/*.json changed since last Sync.
local function HaveDataJsonFilesChanged()
    local cur = captureDataJsonSnapshot()
    if _dataJsonBaselineSnapshot == nil then
        _dataJsonBaselineSnapshot = cur
        return false
    end
    return not dataSnapshotsEqual(_dataJsonBaselineSnapshot, cur)
end

local function TableContains(Tbl, Value)
    if not Tbl or type(Tbl) ~= "table" then return false end
    for _, v in ipairs(Tbl) do
        if v == Value then return true end
    end
    return false
end

local function ValueToString(v)
    if v == nil then return "nil" end
    local ok, s = pcall(function()
        local tv = type(v)
        if tv ~= "userdata" and tv ~= "table" then return tostring(v) end
        if v.ToString then return v:ToString() end
        if v.GetFullName then return v:GetFullName() end
        return tostring(v)
    end)
    if ok and s ~= nil then return tostring(s) end
    return "<?>"
end

--- True if t is empty or keys are exactly 1..n (TArray-style in UE4SS).
local function isSequentialArray(t)
    if type(t) ~= "table" then return false end
    local count, maxKey = 0, 0
    for k, _ in pairs(t) do
        if type(k) ~= "number" or k < 1 or k ~= math.floor(k) then
            return false
        end
        count = count + 1
        if k > maxKey then maxKey = k end
    end
    if count == 0 then return true end
    return maxKey == count
end

local DATA_TABLE_PRINT_MAX_DEPTH = 6
local DATA_TABLE_PRINT_MAX_ARRAY = 64

local FormatValueForPrint

--- TArray / Lua list exposed as userdata with __len and __index.
local function tryFormatUserdataAsIndexedSequence(u, depth)
    local okN, n = pcall(function() return #u end)
    if not okN or type(n) ~= "number" or n < 0 or n ~= math.floor(n) or n > 65536 then
        return nil
    end
    if n > 0 then
        local ok1 = pcall(function() return u[1] end)
        if not ok1 then return nil end
    end
    local parts = {}
    local limit = math.min(n, DATA_TABLE_PRINT_MAX_ARRAY)
    for i = 1, limit do
        local ok, elem = pcall(function() return u[i] end)
        parts[i] = ok and FormatValueForPrint(elem, depth - 1) or "<?>"
    end
    local suffix = ""
    if n > DATA_TABLE_PRINT_MAX_ARRAY then
        suffix = string.format(", ... (+%d)", n - DATA_TABLE_PRINT_MAX_ARRAY)
    end
    return "[" .. table.concat(parts, ", ") .. suffix .. "]"
end

--- Pretty-print for DataTable debug: arrays as [a, b], structs as { k=v, ... }.
FormatValueForPrint = function(v, depth)
    depth = depth or DATA_TABLE_PRINT_MAX_DEPTH
    if depth <= 0 then return "..." end
    if v == nil then return "nil" end

    local tv = type(v)
    if tv == "boolean" or tv == "number" or tv == "string" then return tostring(v) end

    if tv == "userdata" then
        local seq = tryFormatUserdataAsIndexedSequence(v, depth)
        if seq then return seq end
        return ValueToString(v)
    end

    if tv ~= "table" then
        return ValueToString(v)
    end

    if isSequentialArray(v) then
        local parts = {}
        local n = #v
        local limit = math.min(n, DATA_TABLE_PRINT_MAX_ARRAY)
        for i = 1, limit do
            parts[i] = FormatValueForPrint(v[i], depth - 1)
        end
        local suffix = ""
        if n > DATA_TABLE_PRINT_MAX_ARRAY then
            suffix = string.format(", ... (+%d)", n - DATA_TABLE_PRINT_MAX_ARRAY)
        end
        return "[" .. table.concat(parts, ", ") .. suffix .. "]"
    end

    local keys = {}
    for k, _ in pairs(v) do
        keys[#keys + 1] = k
    end
    table.sort(keys, function(a, b)
        return tostring(a) < tostring(b)
    end)
    local parts = {}
    for i, k in ipairs(keys) do
        parts[i] = string.format("%s=%s", tostring(k), FormatValueForPrint(v[k], depth - 1))
    end
    return "{" .. table.concat(parts, ", ") .. "}"
end

--- Copy values from decoded JSON into a live DataTable row (UScriptStruct as Lua table).
--- FNameFields: nil | { fieldName = true, ... } | { fieldName = "map", ... }
---   true  -> scalar FName field
---   "map" -> TArray<FName>: stored as { [FName(v)] = true } for O(1) lookup
local function isStructLike(x)
    return type(x) == "table" or type(x) == "userdata"
end

local function MergeTable(row, jsonRow, FNameFields, forceFName)
    if not row or type(jsonRow) ~= "table" then return end

    for key, val in pairs(jsonRow) do
        local fieldSpec = FNameFields and FNameFields[key]   -- true | "map" | nil
        local wantFName = forceFName or (fieldSpec ~= nil)
        local wantMap   = (fieldSpec == "map")

        if type(val) == "table" then
            local dest = row[key]
            if dest ~= nil and isStructLike(dest) then
                MergeTable(dest, val, FNameFields, wantFName)
            elseif wantFName then
                if wantMap then
                    -- Store TArray<FName> as { [FName(v)] = true } for O(1) membership tests.
                    local m = {}
                    for i = 1, #val do
                        local x = val[i]
                        if type(x) ~= "table" then
                            m[FName(tostring(x))] = true
                        end
                    end
                    row[key] = m
                else
                    local arr = {}
                    for i = 1, #val do
                        local x = val[i]
                        arr[i] = (type(x) == "table") and x or FName(tostring(x))
                    end
                    row[key] = arr
                end
            else
                row[key] = val
            end
        else
            if wantFName then
                row[key] = FName(tostring(val))
            else
                row[key] = val
            end
        end
    end
end

--- e.g. AttackDataTable1 -> "Attack", 1 ; ChatTextDataTable_En -> "ChatText", "_En"
local function parseDataTableJsonStem(stemNoExt)
    local pos = stemNoExt:find("DataTable", 1, true)
    if not pos or pos < 2 then return nil, nil end
    local tableName = stemNoExt:sub(1, pos - 1)
    local suffix = stemNoExt:sub(pos + #"DataTable")
    local tableIndex = nil
    if suffix ~= "" then
        if suffix:match("^%d+$") then
            tableIndex = tonumber(suffix)
        else
            tableIndex = suffix
        end
    end
    return tableName, tableIndex
end

local function buildFullTableName(tableName, tableIndex)
    local full = tableName .. "DataTable"
    if tableIndex ~= nil then
        full = full .. tostring(tableIndex)
    end
    return full
end

local function applyDecodedDataTableJson(dt, data, FNameFields, AddRows)
    local rowsInFile, matchedCount, addCount, errorCount = 0, 0, 0, 0
    for rowName, rowJson in pairs(data) do
        if type(rowJson) == "table" then
            rowsInFile = rowsInFile + 1
            local nameStr = tostring(rowName)
            local row = dt:FindRow(nameStr)

            if row then
                local ok, err = pcall(function()
                    MergeTable(row, rowJson, FNameFields, false)
                end)
                if ok then
                    matchedCount = matchedCount + 1
                else
                    config.Log(string.format("[BetterGameplay] Error row %s: %s\n", nameStr, err))
                    errorCount = errorCount + 1
                end
            elseif AddRows then
                local okAdd, errAdd = pcall(function()
                    dt:AddRow(nameStr, { ID = FName(nameStr) })
                end)
                if okAdd then
                    row = dt:FindRow(nameStr)
                    if row then
                        local ok, err = pcall(function()
                            MergeTable(row, rowJson, FNameFields, false)
                        end)
                        if ok then
                            addCount = addCount + 1
                        else
                            config.Log(string.format("[BetterGameplay] Error new row %s: %s\n", nameStr, err))
                            errorCount = errorCount + 1
                        end
                    end
                else
                    config.Log(string.format("[BetterGameplay] Error AddRow %s: %s\n", nameStr, errAdd))
                    errorCount = errorCount + 1
                end
            end
        end
    end
    return errorCount == 0, matchedCount, addCount, errorCount, rowsInFile
end

--- Apply one patch file; logs relPath under DataTables root, row counts.
local function applyPatchFileToDataTable(dt, absPath, relPath, FNameFields, AddRows)
    local file = io.open(absPath, "r")
    if not file then
        config.Log("[BetterGameplay] Error: could not open " .. relPath .. "\n")
        return false
    end
    local content = file:read("*all")
    file:close()

    local data = json.decode(content)
    if not data or type(data) ~= "table" then
        config.Log("[BetterGameplay] Error: invalid JSON " .. relPath .. "\n")
        return false
    end

    local ok, matched, added, errors, rowsInFile = applyDecodedDataTableJson(dt, data, FNameFields, AddRows)
    config.Log(string.format(
        "[BetterGameplay] Applied: %s\n"
            .. "  Rows in JSON: %d   |   Edited: %d   |   Added: %d   |   Errors: %d\n",
        relPath, rowsInFile, matched, added, errors
    ))
    return ok
end

--- Scans Content/DataTables subfolders at runtime; groups by JSON basename; applies patches in alphabetical path order per table.
--- getPatchOptions(tableName, tableIndex) -> fNameFields, AddRows
local function ApplyAllDiscoveredPatches(getPatchOptions)
    getPatchOptions = getPatchOptions or function() return nil, nil end
    local rootNorm = getDataDirNorm()
    local relPaths = enumeratePatchJsonRelPaths()
    if #relPaths == 0 then
        return true
    end

    local byBasename = {}
    for _, rel in ipairs(relPaths) do
        local base = rel:match("([^/\\]+)$")
        if base then
            byBasename[base] = byBasename[base] or {}
            table.insert(byBasename[base], rel)
        end
    end

    local basenames = {}
    for b, _ in pairs(byBasename) do
        basenames[#basenames + 1] = b
    end
    table.sort(basenames)

    local allOk = true
    for _, base in ipairs(basenames) do
        local paths = byBasename[base]
        table.sort(paths)

        if #base < 6 or not base:lower():match("%.json$") then
            config.Log("[BetterGameplay] Warning: skip non-json file name " .. tostring(base) .. "\n")
        else
            local stem = base:sub(1, #base - 5)
            local tableName, tableIndex = parseDataTableJsonStem(stem)
            if not tableName then
                config.Log("[BetterGameplay] Warning: skip unknown DataTable file name " .. base .. "\n")
            else
                local fullTableName = buildFullTableName(tableName, tableIndex)
                local tablePath = "/Game/DataTables/" .. fullTableName .. "." .. fullTableName
                local dt = StaticFindObject(tablePath)
                if not dt or not dt:IsValid() then
                    config.Log("[BetterGameplay] Error: table not loaded yet " .. tablePath .. " (skipping " .. base .. ")\n")
                    allOk = true
                else
                    local fNameFields, AddRows = getPatchOptions(tableName, tableIndex)
                    for _, rel in ipairs(paths) do
                        local absPath = joinDataRootRel(rootNorm, rel)
                        if not applyPatchFileToDataTable(dt, absPath, rel, fNameFields, AddRows) then
                            allOk = false
                        end
                    end
                end
            end
        end
    end

    return allOk
end

--- Hot-reload variant: re-applies only the patch JSON files that changed since the
--- last baseline snapshot.  Performs a fast cached check on every tick; a fresh
--- directory enumeration is done only when a change is actually detected (so that
--- newly-added files are also picked up at that point).  Updates the baseline
--- automatically on success.  Returns true if nothing changed or all changed files
--- applied cleanly.
local function ApplyChangedDiscoveredPatches(getPatchOptions)
    -- Fast check: cached file list + stored fingerprints — no dir scan per tick.
    local cur = captureDataJsonSnapshot()

    if _dataJsonBaselineSnapshot == nil then
        _dataJsonBaselineSnapshot = cur
        return true
    end

    if dataSnapshotsEqual(_dataJsonBaselineSnapshot, cur) then
        return true
    end

    -- Something changed.  Force a fresh directory enumeration so that
    -- newly-added files are also included in this apply pass.
    _cachedRelPaths = nil
    local freshCur = captureDataJsonSnapshot()

    -- Collect every rel path whose fingerprint differs from the baseline.
    local changedRels = {}
    for rel, fp in pairs(freshCur) do
        if _dataJsonBaselineSnapshot[rel] ~= fp then
            changedRels[#changedRels + 1] = rel
        end
    end
    table.sort(changedRels)

    if #changedRels == 0 then
        -- Only deletions since last baseline; nothing to re-apply.
        _dataJsonBaselineSnapshot = freshCur
        return true
    end

    getPatchOptions = getPatchOptions or function() return nil, nil end
    local rootNorm = getDataDirNorm()
    local allOk = true

    for _, rel in ipairs(changedRels) do
        local base = rel:match("([^/\\]+)$")
        if not base or #base < 6 or not base:lower():match("%.json$") then
            config.Log("[BetterGameplay] Warning: skip non-json file " .. tostring(rel) .. "\n")
        else
            local stem = base:sub(1, #base - 5)
            local tableName, tableIndex = parseDataTableJsonStem(stem)
            if not tableName then
                config.Log("[BetterGameplay] Warning: skip unknown DataTable file name " .. base .. "\n")
            else
                local fullTableName = buildFullTableName(tableName, tableIndex)
                local tablePath = "/Game/DataTables/" .. fullTableName .. "." .. fullTableName
                local dt = StaticFindObject(tablePath)
                if not dt or not dt:IsValid() then
                    config.Log("[BetterGameplay] Error: table not loaded yet " .. tablePath .. " (skipping " .. rel .. ")\n")
                    allOk = false
                else
                    local fNameFields, AddRows = getPatchOptions(tableName, tableIndex)
                    local absPath = joinDataRootRel(rootNorm, rel)
                    if not applyPatchFileToDataTable(dt, absPath, rel, fNameFields, AddRows) then
                        allOk = false
                    end
                end
            end
        end
    end

    if allOk then
        _dataJsonBaselineSnapshot = freshCur
    end

    return allOk
end

--- RowNames: nil | {} = all rows; string = one row; list = only those rows (resolved via FindRow).
local function PrintDataTableRows(TableName, TableIndex, FieldsToPrint, RowNames)
    local fullTableName = TableName .. "DataTable"
    if TableIndex then fullTableName = fullTableName .. TableIndex end
    local dt = StaticFindObject("/Game/DataTables/" .. fullTableName .. "." .. fullTableName)
    if not dt or not dt:IsValid() then return end

    if type(RowNames) == "string" then
        RowNames = { RowNames }
    end

    local function printRowLine(label, rowData)
        local line = "[" .. ValueToString(label) .. "] "
        for _, field in ipairs(FieldsToPrint) do
            local val = "N/A"
            pcall(function()
                val = FormatValueForPrint(rowData[field])
            end)
            line = line .. string.format("| %s: %s ", field, val)
        end
        config.Log(line)
    end

    local function tryFindRow(nameStr)
        local row = nil
        pcall(function() row = dt:FindRow(nameStr) end)
        if row then return row end
        pcall(function() row = dt:FindRow(FName(nameStr)) end)
        return row
    end

    if RowNames and type(RowNames) == "table" and #RowNames > 0 then
        for _, n in ipairs(RowNames) do
            local nameStr = tostring(n)
            local row = tryFindRow(nameStr)
            if row then
                printRowLine(nameStr, row)
            else
                config.Log(string.format("[BetterGameplay] PrintDataTableRows: row not found %q in %s\n", nameStr, fullTableName))
            end
        end
        return
    end

    dt:ForEachRow(function(rowName, rowData)
        printRowLine(rowName, rowData)
    end)
end

return {
    MergeTable = MergeTable,
    ApplyAllDiscoveredPatches = ApplyAllDiscoveredPatches,
    ApplyChangedDiscoveredPatches = ApplyChangedDiscoveredPatches,
    PrintDataTableRows = PrintDataTableRows,
    HaveDataJsonFilesChanged = HaveDataJsonFilesChanged,
    SyncDataJsonFilesBaseline = SyncDataJsonFilesBaseline,
    EnsureDataDirectoryExists = EnsureDataDirectoryExists,
}
